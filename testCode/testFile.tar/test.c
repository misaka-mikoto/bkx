#include <stdio.h>
#include <string.h>

char* fun(char *c)
{
	static char a[]="/etc";
	strcat(a,c);
	return &a;
}

int len(char *c)
{	
	int i=1;
	while(*c++) i++;
	return i;
}

main()
{
	char *b;
	b="/eva.conf";
	printf("%s\n",fun(b));
	printf("%d\n",len(fun(b)));
	char xc[1024];
	char *e=fun(b);
	strcpy(xc,e);
	int i=0;
	while(xc[i]!='\0')
	{printf("%c",xc[i]);
	i++;}
	printf("\n");
	}
